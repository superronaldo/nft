export default {
      staking: {
        1: "0x3C01c6c58E61Ae5fFc0e603abd7ebe5d9d27D97a",
        4: "0x3C01c6c58E61Ae5fFc0e603abd7ebe5d9d27D97a",
      },
      ape: {
        137: "0xe01BF7f7324073eC0661EBdCEba365E1288BB532",
        80001: "0x2BF012030d529579f1366b03747F54C73649572E",
      },
      variable: {
        1: "0xAD93D504631feCA691d0a6EFed72f8344Ee72925",
        4: "0xAD93D504631feCA691d0a6EFed72f8344Ee72925",
      },
    standard: {
        1: "0xe559525118f9Ae71e2b21806B15332D17A00EBfF",
        4: "0xe559525118f9Ae71e2b21806B15332D17A00EBfF",
    },
  };
  